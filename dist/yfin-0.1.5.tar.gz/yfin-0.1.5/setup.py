# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['yfin', 'yfin.symbols', 'yfin.utils']

package_data = \
{'': ['*']}

install_requires = \
['lxml>=4.9.1,<5.0.0',
 'numpy>=1.23.2,<2.0.0',
 'pandas>=1.4.4,<2.0.0',
 'parallel-requests @ git+https://github.com/legout/parallel-requests',
 'requests>=2.28.1,<3.0.0',
 'tqdm>=4.64.1,<5.0.0']

setup_kwargs = {
    'name': 'yfin',
    'version': '0.1.5',
    'description': '',
    'long_description': '# YAHOO Finance API\n\nSimple python wrapper for the yahoo finance api. Heavily uses asyncronous request to speed up data downloads. Optional usage of a rotating proxy is possible.\n',
    'author': 'Volker Lorrmann',
    'author_email': 'volker.lorrmann@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)

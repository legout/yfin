# YAHOO Finance API

Simple python wrapper for the yahoo finance api. Heavily uses asyncronous request to speed up data downloads. Optional usage of a rotating proxy is possible.
